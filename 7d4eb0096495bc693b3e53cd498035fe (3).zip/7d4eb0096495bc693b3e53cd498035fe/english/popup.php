<div class="popup">
		<a class="popup__close arcticmodal-close" href="#">x</a>
		<h4 class="popup__title">Запись на урок</h4>
		<form class="popup__form">
			<input class="popup__input" type="text" placeholder="Ваше имя">
			<input class="popup__input" type="text" placeholder="Ваш телефон">
			<input class="popup__input" type="text" placeholder="Ваш e-mail">
			<a class="popup__btn arcticmodal-close" href="#">записаться</a>
		</form>
	</div>